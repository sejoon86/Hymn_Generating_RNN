import glob, os
import pandas as pd
import numpy as np
import torch
from torch.utils.data import TensorDataset, DataLoader
import time
import matplotlib.pyplot as plt
import midi
import datetime

def MIDI2CSV(filename):

    A = pd.read_csv(filename, header=None, index_col=None).values.transpose()
    #A_temp = A[:,34:97]
    A_temp = A
    print(A_temp.shape)

    A_single_input = []
    previous_note = None
    flag_hold = False
    for N in range(A_temp.shape[0]): # for all ticks
        #print("{} / {}".format(previous_note, flag_hold))

        if flag_hold == True:
            # check IF the previous note is still 1 (holding)
            if A_temp[N,previous_note] == 1:
                # append "hold note" sign, such as '__'
                A_single_input.append(1)
                # don't change flag_hold
                assert flag_hold == True, "flag hold should be True"
                # don't change previous_note
                assert previous_note > 0, "previous note should be > 0"
            # ELIF the previous hold is now NOT 1 (0 or 2)
            elif  A_temp[N,previous_note] != 1:
                # look for starting note and add highest one
                start_arr = np.where(A_temp[N,:]==2)
                # IF there is no starting note
                if len(start_arr[0]) == 0:
                    # add empty note
                    A_single_input.append(0)
                    # change previous note
                    previous_note = None
                    flag_hold = False
                # ELIF there is a starting note
                else: # not empty
                    # add the highest starting note
                    note_arr = np.where(A_temp[N,:]==2)
                    #print(note_arr)
                    note_start = np.max(note_arr)
                    A_single_input.append(note_start)
                    # change "previous note" with current note
                    previous_note = note_start
                    flag_hold = True
        # ELIF flag_hold == False
        else:
            # look for starting note and add highest one
            start_arr = np.where(A_temp[N,:]==2)
            #print(start_arr)
            # IF there is no starting note
            if len(start_arr[0]) == 0:
                # add empty note
                A_single_input.append(0)
                # change previous note
                previous_note = None
                assert flag_hold == False, "should be False"
            # ELIF there is a starting note
            else: # not empty
                # add the highest starting note
                note_arr = np.where(A_temp[N,:]==2)
                #print(note_arr)
                note_start = np.max(note_arr)
                A_single_input.append(note_start)
                # change "previous note" with current note
                previous_note = note_start
                flag_hold = True
    return A_single_input
