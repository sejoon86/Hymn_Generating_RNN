import midi
import numpy as np
import matplotlib.pyplot as plt
import re
import math
import pandas as pd


def print_midi_characteristics(file_name): 
	pattern = midi.read_midifile(file_name)
	data_string = str(pattern)
	A = data_string.splitlines() 

	num_arr = []

	for N in range(len(A)):
		#print(A[N].find('NoteOnEvent'))
		if(A[N].find('resolution') != -1):
			#print(A[N])
			resolution = [int(i) for i in re.findall(r'\d+', A[N])][1]
			#print(resolution)
		
		if(A[N].find('NoteOnEvent') != -1 or A[N].find('NoteOffEvent') != -1):
			#print(A[N])
			#print([int(i) for i in re.findall(r'\d+', A[N])])
			num_arr.append([int(i) for i in re.findall(r'\d+', A[N])])
	np_arr = np.array(num_arr)

	channel = np_arr[:,1]
	unique_channels = set(channel) 
	
	print("[{}] chan = {}, resol ={}".format(file_name, unique_channels, resolution))


def return_midi_np_arr(file_name): 
	pattern = midi.read_midifile(file_name)
	data_string = str(pattern)
	A = data_string.splitlines() 

	num_arr = []

	for N in range(len(A)):
		#print(A[N].find('NoteOnEvent'))
		if(A[N].find('resolution') != -1):
			#print(A[N])
			resolution = [int(i) for i in re.findall(r'\d+', A[N])][1]
			#print(resolution)
		
		if(A[N].find('NoteOnEvent') != -1 or A[N].find('NoteOffEvent') != -1):
			#print(A[N])
			#print([int(i) for i in re.findall(r'\d+', A[N])])
			num_arr.append([int(i) for i in re.findall(r'\d+', A[N])])
	np_arr = np.array(num_arr)

	channel = np_arr[:,1]
	unique_channels = set(channel) 
	
	return resolution, np_arr
	#print(np_arr)
 
 
 
 
 
def etc_char_midi(file_name): 
	pattern = midi.read_midifile(file_name)
	data_string = str(pattern)
	A = data_string.splitlines() 

	num_arr = []

	for N in range(len(A)):
		if(A[N].find('TimeSignatureEvent') != -1):
			resolution = [int(i) for i in re.findall(r'\d+', A[N])][1]
			TimeSignatureEvent_arr = [int(i) for i in re.findall(r'\d+', A[N])][1:]
	 	
	return TimeSignatureEvent_arr
    
 